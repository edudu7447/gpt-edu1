@echo off
setlocal
cd /d "%~dp0"
if exist ".runtime\node.exe" (
  ".runtime\node.exe" "server.mjs"
) else (
  where node >nul 2>&1
  if errorlevel 1 (
    echo Falta Node.js. Descarga el paquete Windows completo o instala Node.js LTS desde https://nodejs.org
    pause
    exit /b 1
  )
  node "server.mjs"
)
if errorlevel 1 pause
