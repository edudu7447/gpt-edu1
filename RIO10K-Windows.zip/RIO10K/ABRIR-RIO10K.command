#!/bin/sh
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)" || exit 1
if [ -x ".runtime/bin/node" ]; then
  ".runtime/bin/node" "server.mjs"
elif command -v node >/dev/null 2>&1; then
  node "server.mjs"
else
  printf '%s\n' 'Falta Node.js. Usa el paquete completo para tu sistema o instala Node.js LTS desde https://nodejs.org'
  printf '%s\n' 'Pulsa Enter para cerrar.'
  read -r rio10k_wait
  exit 1
fi
