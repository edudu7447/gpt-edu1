/** Local-only launcher for the prebuilt PWA. No npm install or remote service. */
import http from "node:http";
import fs from "node:fs";
import fsp from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";

const folder = path.dirname(fileURLToPath(import.meta.url));
const root = fs.existsSync(path.join(folder, "web", "index.html"))
  ? path.join(folder, "web")
  : path.join(folder, "..", "dist");
const port = Number(process.env.RIO10K_PORT || 4178);
if (!Number.isInteger(port) || port < 1024 || port > 65535)
  throw Error("RIO10K_PORT debe ser un puerto entre 1024 y 65535.");
const origin = `http://127.0.0.1:${port}`;
const noOpen = process.argv.includes("--no-open");
const mime = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".webmanifest": "application/manifest+json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".ico": "image/x-icon",
  ".woff2": "font/woff2",
};
const realRoot = await fsp.realpath(root).catch(() => {
  throw Error(
    "Falta la carpeta web. Descomprime todo el ZIP antes de iniciar RIO10K.",
  );
});

function launch(command, args) {
  return new Promise((resolve) => {
    const child = spawn(command, args, { detached: true, stdio: "ignore" });
    child.once("error", () => resolve(false));
    child.once("spawn", () => {
      child.unref();
      resolve(true);
    });
  });
}
async function openApp() {
  if (noOpen) return;
  const candidates =
    process.platform === "win32"
      ? [
          ["LOCALAPPDATA", "Google/Chrome/Application/chrome.exe"],
          ["PROGRAMFILES", "Google/Chrome/Application/chrome.exe"],
          ["PROGRAMFILES(X86)", "Google/Chrome/Application/chrome.exe"],
          ["PROGRAMFILES(X86)", "Microsoft/Edge/Application/msedge.exe"],
          ["PROGRAMFILES", "Microsoft/Edge/Application/msedge.exe"],
        ].map(([base, suffix]) => path.join(process.env[base] || "", suffix))
      : process.platform === "darwin"
        ? [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
            path.join(
              process.env.HOME || "",
              "Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            ),
          ]
        : [
            "/usr/bin/google-chrome",
            "/usr/bin/google-chrome-stable",
            "/usr/bin/chromium",
            "/usr/bin/chromium-browser",
            "/usr/bin/microsoft-edge",
          ];
  for (const executable of candidates)
    if (
      fs.existsSync(executable) &&
      (await launch(executable, [`--app=${origin}`]))
    )
      return;
  const opened =
    process.platform === "win32"
      ? await launch("rundll32.exe", ["url.dll,FileProtocolHandler", origin])
      : await launch(process.platform === "darwin" ? "open" : "xdg-open", [
          origin,
        ]);
  if (!opened) console.log(`Abre esta direccion en tu navegador: ${origin}`);
}
function response(res, status, message) {
  res.writeHead(status, {
    "Content-Type": "text/plain; charset=utf-8",
    "Cache-Control": "no-store",
  });
  res.end(message);
}
const server = http.createServer(async (req, res) => {
  try {
    if (req.headers.host !== `127.0.0.1:${port}`) {
      response(res, 400, `Abre RIO10K desde ${origin}`);
      return;
    }
    if (!["GET", "HEAD"].includes(req.method)) {
      res.setHeader("Allow", "GET, HEAD");
      response(res, 405, "Metodo no permitido.");
      return;
    }
    const url = new URL(req.url, origin);
    if (url.pathname === "/__rio10k__/status") {
      res.writeHead(200, {
        "Content-Type": "application/json",
        "Cache-Control": "no-store",
      });
      res.end(
        req.method === "HEAD"
          ? undefined
          : JSON.stringify({ app: "rio10k-local", version: 1 }),
      );
      return;
    }
    let name;
    try {
      name = decodeURIComponent(url.pathname);
    } catch {
      response(res, 400, "Direccion invalida.");
      return;
    }
    if (
      name.includes("\0") ||
      name.split(/[\\/]/).some((part) => part.startsWith("."))
    ) {
      response(res, 403, "Ruta no disponible.");
      return;
    }
    if (name === "/") name = "/index.html";
    const target = path.resolve(realRoot, `.${name}`);
    if (!target.startsWith(realRoot + path.sep)) {
      response(res, 403, "Ruta no disponible.");
      return;
    }
    const real = await fsp.realpath(target).catch(() => null);
    if (!real || !real.startsWith(realRoot + path.sep)) {
      response(res, 404, "Archivo no encontrado.");
      return;
    }
    const stat = await fsp.stat(real);
    if (!stat.isFile()) {
      response(res, 404, "Archivo no encontrado.");
      return;
    }
    res.writeHead(200, {
      "Content-Type": mime[path.extname(real)] || "application/octet-stream",
      "Content-Length": stat.size,
      "Cache-Control": name.startsWith("/assets/")
        ? "public, max-age=31536000, immutable"
        : "no-cache",
      "X-Content-Type-Options": "nosniff",
    });
    if (req.method === "HEAD") {
      res.end();
      return;
    }
    const stream = fs.createReadStream(real);
    stream.on("error", () => res.destroy());
    stream.pipe(res);
  } catch (error) {
    if (!res.headersSent)
      response(res, 500, "No se pudo leer el archivo local.");
    else res.destroy();
    console.error(error.message);
  }
});
server.on("error", async (error) => {
  if (error.code === "EADDRINUSE") {
    try {
      const reply = await fetch(`${origin}/__rio10k__/status`, {
        signal: AbortSignal.timeout(2000),
      });
      const data = await reply.json();
      if (data.app === "rio10k-local") {
        console.log("RIO10K ya esta abierto. Abriendo su ventana...");
        await openApp();
        return;
      }
    } catch {}
    console.error(
      `El puerto ${port} esta ocupado por otra aplicacion. Cierra esa aplicacion y vuelve a intentarlo. No cambies de puerto durante un torneo.`,
    );
  } else console.error(`No se pudo iniciar RIO10K: ${error.message}`);
  process.exitCode = 1;
});
server.listen(port, "127.0.0.1", async () => {
  console.log(
    `\n  RIO10K - TORNEO LOCAL\n  ${origin}\n\n  PIN de demostracion: 1010 (si aun no lo cambiaste).\n  Mantén esta ventana abierta mientras usas el torneo.\n  Para cerrar el servidor pulsa Ctrl+C.\n`,
  );
  await openApp();
});
for (const signal of ["SIGINT", "SIGTERM"])
  process.on(signal, () => server.close(() => process.exit(0)));
