const CACHE='rio10k-1e31a7bef4a4';
const FILES=["assets/html2canvas.esm-DXEQVQnt.js","assets/index-CnYpahmF.css","assets/index-fzepl9i3.js","assets/index.es-ChrBVyM6.js","assets/jspdf.es.min-OwamiGBo.js","assets/purify.es-18JuyMri.js","brand-rio10k.png","icon-192.png","icon-512.png","index.html","logo.svg","manifest.webmanifest","poker-pattern.svg"];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(FILES.map(f=>new URL(f,self.registration.scope).href)))));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('rio10k-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{if(event.request.method!=='GET'||new URL(event.request.url).origin!==self.location.origin)return;
event.respondWith((async()=>{const cache=await caches.open(CACHE);if(event.request.mode==='navigate')return await cache.match(new URL('index.html',self.registration.scope).href)||fetch(event.request);const cached=await cache.match(event.request,{ignoreVary:true});return cached||fetch(event.request)})())});
