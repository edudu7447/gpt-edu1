const CACHE='rio10k-ff3c108f476a';
const FILES=["assets/html2canvas.esm-DXEQVQnt.js","assets/index-BAwfYKvY.js","assets/index-Ws5xqumE.css","assets/index.es-DKxc5q0W.js","assets/jspdf.es.min-CMNPEX9B.js","assets/purify.es-18JuyMri.js","icon-192.png","icon-512.png","index.html","logo.svg","manifest.webmanifest"];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(FILES.map(f=>new URL(f,self.registration.scope).href)))));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('rio10k-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{if(event.request.method!=='GET'||new URL(event.request.url).origin!==self.location.origin)return;
event.respondWith((async()=>{const cache=await caches.open(CACHE);if(event.request.mode==='navigate')return await cache.match(new URL('index.html',self.registration.scope).href)||fetch(event.request);const cached=await cache.match(event.request,{ignoreVary:true});return cached||fetch(event.request)})())});
